# 🌍 EcoMine - Mine Coins by Doing Good

A beautiful, feature-rich Flask web application that rewards users with EcoCoins for completing eco-friendly activities. Users can upload proof of their green actions, track their environmental impact, compete on leaderboards, and redeem rewards!

## ✨ Features

- 🔐 **User Authentication** - Secure registration and login system
- 📤 **Activity Upload** - Upload photos of eco-friendly activities
- 💰 **EcoCoins System** - Earn coins for verified green actions
- 👨‍💼 **Admin Panel** - Verify/reject user submissions
- 📊 **Impact Tracker** - Beautiful charts showing your environmental impact
- 🏆 **Leaderboard** - Global rankings with confetti for top performers
- 🎁 **Rewards System** - Redeem coins for eco-products or donations
- 🤖 **AI Habit Coach** - Get daily eco-tips and suggestions
- 🌓 **Dark/Light Theme** - Toggle between beautiful green themes
- 📱 **Responsive Design** - Works perfectly on all devices
- 🎉 **Animations** - Coin animations, confetti effects, smooth transitions

## 🎨 Design Highlights

- Modern gradient design with green eco-theme
- Smooth animations and transitions
- Glass-morphism effects
- Interactive charts using Chart.js
- Beautiful card-based layouts
- Responsive grid systems

## 📁 Project Structure

```
ecomine/
│
├── app.py                      # Main Flask application
├── ecomine.db                  # SQLite database (auto-created)
│
├── templates/
│   ├── base.html               # Base template with navbar & footer
│   ├── home.html               # Landing page
│   ├── login.html              # Login page
│   ├── register.html           # Registration page
│   ├── dashboard.html          # User dashboard
│   ├── upload_proof.html       # Upload activity proof
│   ├── redeem.html             # Redeem rewards
│   ├── impact.html             # Impact tracker with charts
│   ├── team.html               # Leaderboard
│   └── admin.html              # Admin verification panel
│
└── static/
    ├── css/
    │   └── style.css           # Complete styling with themes
    ├── js/
    │   └── main.js             # JavaScript for interactions
    └── uploads/                # User-uploaded images (auto-created)
```

## 🚀 Installation & Setup

### Prerequisites

- Python 3.7 or higher
- pip (Python package manager)

### Step 1: Clone or Download

Download all the files and place them in a folder named `ecomine`.

### Step 2: Install Dependencies

```bash
pip install flask werkzeug
```

### Step 3: Run the Application

```bash
python app.py
```

The application will start on `http://127.0.0.1:5000/`

### Step 4: Create Admin Account

1. Register a new account with username: `admin`
2. This account will have access to the admin verification panel

## 💡 How to Use

### For Users:

1. **Register** - Create a new account
2. **Login** - Access your dashboard
3. **Upload Activity** - Take a photo of your eco-activity and upload it
4. **Wait for Verification** - Admin will approve/reject your submission
5. **Earn Coins** - Get EcoCoins when approved
6. **Track Impact** - View your environmental impact statistics
7. **Redeem Rewards** - Use coins to get eco-products or donate
8. **Compete** - Check the leaderboard and climb to the top!

### For Admins:

1. Login with username `admin`
2. Access Admin Panel from navbar
3. Review submitted proofs
4. Approve or reject submissions
5. Coins are automatically awarded on approval

## 🎯 Activity Types & Rewards

| Activity | Coins | CO₂ Saved |
|----------|-------|-----------|
| 🌳 Plant a Tree | 15 | 5.0 kg |
| 🏖️ Beach Cleanup | 12 | 3.0 kg |
| ♻️ Recycle Waste | 10 | 2.5 kg |
| 🗑️ Reduce Waste | 10 | 2.0 kg |
| 🚌 Public Transport | 8 | 1.5 kg |
| 🌱 Compost | 7 | 1.8 kg |
| 💧 Save Water | 6 | 1.0 kg |

## 🎁 Available Rewards

- 🌳 Plant a Tree (50 coins)
- 🛍️ Eco Tote Bag (100 coins)
- 💚 NGO Donation (150 coins)
- 🍴 Bamboo Utensil Set (200 coins)
- ☀️ Solar Power Bank (300 coins)

## 🛠️ Customization

### Change Theme Colors

Edit `static/css/style.css` and modify the CSS variables:

```css
:root {
    --primary: #10b981;    /* Main green color */
    --secondary: #34d399;   /* Secondary green */
    --accent: #6ee7b7;      /* Accent color */
}
```

### Add More Activities

In `app.py`, modify the `calculate_impact()` function:

```python
impacts = {
    'your_activity': {'coins': 10, 'co2': 2.0}
}
```

Then add the option in `upload_proof.html`.

### Add More Rewards

Directly add to the database or modify the initialization in `app.py`:

```python
rewards = [
    ('Reward Name', cost, 'Description'),
]
```

## 📊 Database Schema

### Users Table
- id, username, email, password, coins, activities, co2_saved, created_at

### Proofs Table
- id, user_id, activity_type, image_path, status, coins_earned, created_at

### Rewards Table
- id, name, cost, description

## 🎨 Features in Detail

### Theme Toggle
- Light and dark mode with beautiful green themes
- Persistent selection (saved in localStorage)
- Smooth transitions between themes

### Coin Animation
- Animated coins when rewards are earned
- Confetti effect on achievements
- Smooth pop-up animations

### Impact Visualization
- Doughnut chart for activity breakdown
- Real-time statistics
- CO₂ equivalent calculations

### AI Habit Coach
- Random eco-tips
- Motivational suggestions
- "Get New Tip" button for fresh ideas

## 🔒 Security Features

- Password hashing using Werkzeug
- Session-based authentication
- SQL injection prevention with parameterized queries
- File upload validation
- Admin-only routes protection

## 📱 Responsive Design

- Mobile-first approach
- Adapts to all screen sizes
- Touch-friendly interface
- Optimized images

## 🐛 Troubleshooting

**Database Error:**
- Delete `ecomine.db` and restart the app to recreate

**Upload Folder Error:**
- Ensure `static/uploads/` folder exists or let the app create it

**Admin Access:**
- Make sure to register with username exactly as `admin`

**Chart Not Showing:**
- Ensure you have internet connection for Chart.js CDN

## 🚀 Deployment Tips

For production deployment:

1. Change the secret key in `app.py`
2. Set `debug=False`
3. Use a production WSGI server (gunicorn, waitress)
4. Use PostgreSQL instead of SQLite
5. Set up proper file storage (AWS S3, etc.)
6. Add SSL certificate for HTTPS
7. Implement rate limiting
8. Add email verification

## 📝 Future Enhancements

- Email notifications
- Social sharing features
- Team challenges
- Monthly competitions
- Mobile app version
- API for third-party integrations
- Blockchain integration
- Real tree planting partnerships

## 👏 Credits

- **Fonts:** Google Fonts (Poppins)
- **Charts:** Chart.js
- **Icons:** Emoji
- **Design:** Custom green eco-theme

## 📄 License

This project is free to use for educational and personal purposes.

## 🌟 Contributing

Feel free to fork, modify, and improve this project! Contributions are welcome.

---

**Made with 💚 for a greener planet!**

Start your eco-journey today with EcoMine! 🌍✨