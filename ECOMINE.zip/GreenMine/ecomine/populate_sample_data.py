import sqlite3
from werkzeug.security import generate_password_hash
from datetime import datetime, timedelta
import random

def populate_sample_data():
    conn = sqlite3.connect('ecomine.db')
    c = conn.cursor()
    
    # Sample users
    sample_users = [
        ('admin', 'admin@ecomine.com', '123', 250, 18, 45.5),
        ('alice_green', 'alice@example.com', '123', 180, 15, 38.0),
        ('bob_eco', 'bob@example.com', '123', 220, 20, 52.5),
        ('charlie_earth', 'charlie@example.com', '123', 150, 12, 30.0),
        ('diana_nature', 'diana@example.com', '123', 195, 16, 42.0),
        ('eco_warrior', 'warrior@example.com', '123', 280, 22, 58.5),
        ('green_hero', 'hero@example.com', '123', 165, 13, 34.5),
        ('planet_saver', 'saver@example.com', '123', 140, 11, 28.0),
    ]
    
    print("Creating sample users...")
    user_ids = {}
    for username, email, password, coins, activities, co2 in sample_users:
        hashed_password = generate_password_hash(password)
        try:
            c.execute('''INSERT INTO users (username, email, password, coins, activities, co2_saved) 
                        VALUES (?, ?, ?, ?, ?, ?)''',
                     (username, email, hashed_password, coins, activities, co2))
            user_ids[username] = c.lastrowid
            print(f"✓ Created user: {username}")
        except sqlite3.IntegrityError:
            print(f"✗ User {username} already exists, skipping...")
            c.execute('SELECT id FROM users WHERE username = ?', (username,))
            user_ids[username] = c.fetchone()[0]
    
    # Sample activities with realistic data
    activities_list = [
        'plant_tree', 'recycle', 'beach_cleanup', 'public_transport', 
        'reduce_waste', 'compost', 'save_water'
    ]
    
    activity_impact = {
        'plant_tree': 15,
        'beach_cleanup': 12,
        'recycle': 10,
        'reduce_waste': 10,
        'public_transport': 8,
        'compost': 7,
        'save_water': 6
    }
    
    print("\nCreating sample activity submissions...")
    
    # Create approved activities for each user
    for username, user_id in user_ids.items():
        if username == 'admin':
            num_activities = 18
        else:
            num_activities = random.randint(8, 20)
        
        for i in range(num_activities):
            activity_type = random.choice(activities_list)
            coins_earned = activity_impact[activity_type]
            
            # Random date within last 30 days
            days_ago = random.randint(0, 30)
            created_at = (datetime.now() - timedelta(days=days_ago)).strftime('%Y-%m-%d %H:%M:%S')
            
            # 90% approved, 10% pending for variety
            status = 'approved' if random.random() < 0.9 else 'pending'
            coins = coins_earned if status == 'approved' else 0
            
            c.execute('''INSERT INTO proofs (user_id, activity_type, image_path, status, coins_earned, created_at)
                        VALUES (?, ?, ?, ?, ?, ?)''',
                     (user_id, activity_type, f'sample_{username}_{i}.jpg', status, coins, created_at))
    
    print(f"✓ Created sample activities for all users")
    
    # Add some pending activities for admin to review
    print("\nCreating pending activities for admin review...")
    pending_users = ['alice_green', 'bob_eco', 'charlie_earth']
    for username in pending_users:
        user_id = user_ids[username]
        activity_type = random.choice(activities_list)
        c.execute('''INSERT INTO proofs (user_id, activity_type, image_path, status, coins_earned)
                    VALUES (?, ?, ?, ?, ?)''',
                 (user_id, activity_type, f'pending_{username}.jpg', 'pending', 0))
    
    print(f"✓ Created {len(pending_users)} pending activities")
    
    conn.commit()
    conn.close()
    
    print("\n" + "="*60)
    print("🎉 SAMPLE DATA POPULATED SUCCESSFULLY!")
    print("="*60)
    print("\n📊 Summary:")
    print(f"   • {len(sample_users)} Users created")
    print(f"   • ~150-200 Activities generated")
    print(f"   • {len(pending_users)} Pending reviews for admin")
    print("\n🔐 Login Credentials:")
    print("   Admin Account:")
    print("   - Username: admin")
    print("   - Password: admin123")
    print("\n   Sample Users (all have password: password123):")
    for username, _, _, coins, activities, co2 in sample_users[1:]:
        print(f"   - {username} ({coins} coins, {activities} activities)")
    print("\n🚀 Start the app: python app.py")
    print("   Then go to: http://127.0.0.1:5000")
    print("="*60)

if __name__ == '__main__':
    try:
        populate_sample_data()
    except Exception as e:
        print(f"\n❌ Error: {e}")
        print("Make sure ecomine.db exists. Run 'python app.py' first to create it.")