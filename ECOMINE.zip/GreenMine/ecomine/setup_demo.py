"""
EcoMine Demo Setup Script
Run this to populate your database with sample users and data
"""

import sqlite3
from werkzeug.security import generate_password_hash
from datetime import datetime, timedelta
import random
import os

def setup_demo():
    print("="*70)
    print("🌱 EcoMine Demo Setup")
    print("="*70)
    
    # Check if database exists
    if not os.path.exists('ecomine.db'):
        print("\n❌ Database not found!")
        print("Please run 'python app.py' first to create the database.")
        return
    
    conn = sqlite3.connect('ecomine.db')
    c = conn.cursor()
    
    # Sample users with realistic data
    print("\n📝 Creating sample users...")
    sample_users = [
        ('admin', 'admin@ecomine.com', 'admin123', 250, 18, 45.5),
        ('alice_green', 'alice@example.com', 'password123', 180, 15, 38.0),
        ('bob_eco', 'bob@example.com', 'password123', 220, 20, 52.5),
        ('charlie_earth', 'charlie@example.com', 'password123', 150, 12, 30.0),
        ('diana_nature', 'diana@example.com', 'password123', 195, 16, 42.0),
        ('eco_warrior', 'warrior@example.com', 'password123', 280, 22, 58.5),
        ('green_hero', 'hero@example.com', 'password123', 165, 13, 34.5),
        ('planet_saver', 'saver@example.com', 'password123', 140, 11, 28.0),
    ]
    
    user_ids = {}
    for username, email, password, coins, activities, co2 in sample_users:
        hashed_password = generate_password_hash(password)
        try:
            c.execute('''INSERT INTO users (username, email, password, coins, activities, co2_saved) 
                        VALUES (?, ?, ?, ?, ?, ?)''',
                     (username, email, hashed_password, coins, activities, co2))
            user_ids[username] = c.lastrowid
            print(f"   ✓ {username}")
        except sqlite3.IntegrityError:
            c.execute('SELECT id FROM users WHERE username = ?', (username,))
            result = c.fetchone()
            if result:
                user_ids[username] = result[0]
                print(f"   ⚠ {username} (already exists)")
    
    # Activity types and their rewards
    activities_list = [
        'plant_tree', 'recycle', 'beach_cleanup', 'public_transport', 
        'reduce_waste', 'compost', 'save_water'
    ]
    
    activity_impact = {
        'plant_tree': 15,
        'beach_cleanup': 12,
        'recycle': 10,
        'reduce_waste': 10,
        'public_transport': 8,
        'compost': 7,
        'save_water': 6
    }
    
    print("\n📤 Creating sample activities...")
    total_activities = 0
    
    for username, user_id in user_ids.items():
        num_activities = random.randint(10, 20)
        
        for i in range(num_activities):
            activity_type = random.choice(activities_list)
            coins_earned = activity_impact[activity_type]
            
            # Random date within last 30 days
            days_ago = random.randint(0, 30)
            created_at = (datetime.now() - timedelta(days=days_ago)).strftime('%Y-%m-%d %H:%M:%S')
            
            # 85% approved, 15% pending
            status = 'approved' if random.random() < 0.85 else 'pending'
            coins = coins_earned if status == 'approved' else 0
            
            # Use placeholder image name
            image_name = f'demo_{username}_{activity_type}_{i}.jpg'
            
            c.execute('''INSERT INTO proofs (user_id, activity_type, image_path, status, coins_earned, created_at)
                        VALUES (?, ?, ?, ?, ?, ?)''',
                     (user_id, activity_type, image_name, status, coins, created_at))
            total_activities += 1
    
    print(f"   ✓ Created {total_activities} activities")
    
    # Create some pending activities for admin review
    print("\n⏳ Creating pending reviews...")
    pending_count = 0
    for username in ['alice_green', 'bob_eco', 'charlie_earth']:
        user_id = user_ids[username]
        activity_type = random.choice(activities_list)
        image_name = f'pending_{username}_{activity_type}.jpg'
        
        c.execute('''INSERT INTO proofs (user_id, activity_type, image_path, status, coins_earned)
                    VALUES (?, ?, ?, ?, ?)''',
                 (user_id, activity_type, image_name, 'pending', 0))
        pending_count += 1
    
    print(f"   ✓ Created {pending_count} pending submissions")
    
    conn.commit()
    conn.close()
    
    # Create dummy images
    print("\n📷 Creating placeholder images...")
    create_dummy_images()
    
    # Print summary
    print("\n" + "="*70)
    print("✅ DEMO DATA SETUP COMPLETE!")
    print("="*70)
    print(f"\n📊 Summary:")
    print(f"   • Users: {len(sample_users)}")
    print(f"   • Activities: {total_activities}")
    print(f"   • Pending Reviews: {pending_count}")
    
    print(f"\n🔐 Login Credentials:")
    print(f"\n   👨‍💼 Admin Account:")
    print(f"   Username: admin")
    print(f"   Password: admin123")
    
    print(f"\n   👥 Sample Users (password: password123):")
    print(f"   • alice_green (180 coins)")
    print(f"   • bob_eco (220 coins)")
    print(f"   • charlie_earth (150 coins)")
    print(f"   • eco_warrior (280 coins) - Top user!")
    
    print(f"\n🚀 Next Steps:")
    print(f"   1. Run: python app.py")
    print(f"   2. Open: http://127.0.0.1:5000")
    print(f"   3. Login as 'admin' to see pending reviews")
    print(f"   4. Check the leaderboard to see rankings!")
    print("="*70 + "\n")

def create_dummy_images():
    """Create simple colored placeholder images"""
    upload_folder = 'static/uploads'
    os.makedirs(upload_folder, exist_ok=True)
    
    try:
        from PIL import Image, ImageDraw, ImageFont
        
        colors = ['#10b981', '#34d399', '#6ee7b7', '#a7f3d0', '#059669']
        
        # Create a few sample images
        for i in range(10):
            color = colors[i % len(colors)]
            img = Image.new('RGB', (400, 300), color=color)
            draw = ImageDraw.Draw(img)
            
            try:
                font = ImageFont.truetype("arial.ttf", 40)
            except:
                font = ImageFont.load_default()
            
            draw.text((200, 150), f"Sample Image {i+1}", fill='white', anchor='mm', font=font)
            
            filename = f'demo_sample_{i}.jpg'
            filepath = os.path.join(upload_folder, filename)
            img.save(filepath, 'JPEG')
        
        print(f"   ✓ Created 10 placeholder images")
        
    except ImportError:
        print("   ⚠ Pillow not installed - skipping image creation")
        print("   Images will show as broken links (functionality still works!)")

if __name__ == '__main__':
    try:
        setup_demo()
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()