from PIL import Image, ImageDraw, ImageFont
import os

def create_sample_images():
    """Create sample placeholder images for activities"""
    
    # Create uploads folder if it doesn't exist
    upload_folder = 'static/uploads'
    os.makedirs(upload_folder, exist_ok=True)
    
    # Activity emojis and colors
    activities = {
        'plant_tree': ('🌳', '#10b981', 'Tree Planted'),
        'recycle': ('♻️', '#34d399', 'Recycling'),
        'beach_cleanup': ('🏖️', '#6ee7b7', 'Beach Cleanup'),
        'public_transport': ('🚌', '#a7f3d0', 'Public Transport'),
        'reduce_waste': ('🗑️', '#d1fae5', 'Waste Reduced'),
        'compost': ('🌱', '#059669', 'Composting'),
        'save_water': ('💧', '#047857', 'Water Saved'),
    }
    
    usernames = ['admin', 'alice_green', 'bob_eco', 'charlie_earth', 'diana_nature', 
                 'eco_warrior', 'green_hero', 'planet_saver']
    
    print("Creating sample images...")
    count = 0
    
    for username in usernames:
        for i in range(20):  # 20 images per user
            activity = list(activities.keys())[i % len(activities)]
            emoji, color, label = activities[activity]
            
            # Create image
            img = Image.new('RGB', (400, 300), color=color)
            draw = ImageDraw.Draw(img)
            
            # Try to use a font, fallback to default if not available
            try:
                font_large = ImageFont.truetype("arial.ttf", 80)
                font_small = ImageFont.truetype("arial.ttf", 30)
            except:
                font_large = ImageFont.load_default()
                font_small = ImageFont.load_default()
            
            # Draw text
            draw.text((200, 100), emoji, fill='white', anchor='mm', font=font_large)
            draw.text((200, 200), label, fill='white', anchor='mm', font=font_small)
            draw.text((200, 250), f'by {username}', fill='white', anchor='mm', font=font_small)
            
            # Save image
            filename = f'sample_{username}_{i}.jpg'
            filepath = os.path.join(upload_folder, filename)
            img.save(filepath, 'JPEG', quality=85)
            count += 1
    
    # Create pending images
    for username in ['alice_green', 'bob_eco', 'charlie_earth']:
        activity = 'plant_tree'
        emoji, color, label = activities[activity]
        
        img = Image.new('RGB', (400, 300), color='#f59e0b')
        draw = ImageDraw.Draw(img)
        
        try:
            font_large = ImageFont.truetype("arial.ttf", 80)
            font_small = ImageFont.truetype("arial.ttf", 30)
        except:
            font_large = ImageFont.load_default()
            font_small = ImageFont.load_default()
        
        draw.text((200, 100), '⏳', fill='white', anchor='mm', font=font_large)
        draw.text((200, 200), 'Pending Review', fill='white', anchor='mm', font=font_small)
        draw.text((200, 250), f'by {username}', fill='white', anchor='mm', font=font_small)
        
        filename = f'pending_{username}.jpg'
        filepath = os.path.join(upload_folder, filename)
        img.save(filepath, 'JPEG', quality=85)
        count += 1
    
    print(f"✓ Created {count} sample images in {upload_folder}/")
    return count

if __name__ == '__main__':
    try:
        # Check if PIL is available
        count = create_sample_images()
        print(f"\n🎉 Successfully created {count} sample images!")
        print(f"📁 Location: static/uploads/")
    except ImportError:
        print("\n⚠️  Pillow not installed. Installing...")
        print("Run: pip install Pillow")
        print("Then run this script again.")
    except Exception as e:
        print(f"\n❌ Error: {e}")