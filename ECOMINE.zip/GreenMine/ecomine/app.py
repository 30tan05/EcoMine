from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from datetime import datetime
import os
import sqlite3
import random

app = Flask(__name__)
app.secret_key = 'your-secret-key-change-this'
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Ensure upload folder exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Database setup
def init_db():
    conn = sqlite3.connect('ecomine.db')
    c = conn.cursor()
    
    c.execute('''CREATE TABLE IF NOT EXISTS users
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  username TEXT UNIQUE NOT NULL,
                  email TEXT UNIQUE NOT NULL,
                  password TEXT NOT NULL,
                  coins INTEGER DEFAULT 0,
                  activities INTEGER DEFAULT 0,
                  co2_saved REAL DEFAULT 0,
                  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
    
    c.execute('''CREATE TABLE IF NOT EXISTS proofs
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  user_id INTEGER,
                  activity_type TEXT NOT NULL,
                  image_path TEXT NOT NULL,
                  status TEXT DEFAULT 'pending',
                  coins_earned INTEGER DEFAULT 0,
                  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                  FOREIGN KEY (user_id) REFERENCES users (id))''')
    
    c.execute('''CREATE TABLE IF NOT EXISTS rewards
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  name TEXT NOT NULL,
                  cost INTEGER NOT NULL,
                  description TEXT)''')
    
    # Add default rewards if none exist
    c.execute("SELECT COUNT(*) FROM rewards")
    if c.fetchone()[0] == 0:
        rewards = [
            ('Plant a Tree', 50, 'We plant a tree in your name'),
            ('Eco Tote Bag', 100, 'Sustainable cotton tote bag'),
            ('NGO Donation', 150, 'Donate to environmental NGO'),
            ('Bamboo Utensil Set', 200, 'Reusable bamboo cutlery'),
            ('Solar Power Bank', 300, 'Eco-friendly phone charger')
        ]
        c.executemany("INSERT INTO rewards (name, cost, description) VALUES (?, ?, ?)", rewards)
    
    conn.commit()
    conn.close()

init_db()

# Helper functions
def get_db():
    conn = sqlite3.connect('ecomine.db')
    conn.row_factory = sqlite3.Row
    return conn

def calculate_impact(activity_type):
    impacts = {
        'plant_tree': {'coins': 15, 'co2': 5.0},
        'recycle': {'coins': 10, 'co2': 2.5},
        'beach_cleanup': {'coins': 12, 'co2': 3.0},
        'public_transport': {'coins': 8, 'co2': 1.5},
        'reduce_waste': {'coins': 10, 'co2': 2.0},
        'compost': {'coins': 7, 'co2': 1.8},
        'save_water': {'coins': 6, 'co2': 1.0}
    }
    return impacts.get(activity_type, {'coins': 10, 'co2': 2.0})

# Routes
@app.route('/')
def home():
    db = get_db()
    stats = db.execute('''SELECT 
                          SUM(coins) as total_coins,
                          SUM(activities) as total_activities,
                          SUM(co2_saved) as total_co2
                          FROM users''').fetchone()
    db.close()
    return render_template('home.html', stats=stats)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        confirm = request.form['confirm_password']
        
        if password != confirm:
            flash('Passwords do not match!', 'error')
            return redirect(url_for('register'))
        
        hashed_password = generate_password_hash(password)
        
        try:
            db = get_db()
            db.execute('INSERT INTO users (username, email, password) VALUES (?, ?, ?)',
                      (username, email, hashed_password))
            db.commit()
            db.close()
            flash('Registration successful! Please login.', 'success')
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash('Username or email already exists!', 'error')
            return redirect(url_for('register'))
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        db = get_db()
        user = db.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
        db.close()
        
        if user and check_password_hash(user['password'], password):
            session['user_id'] = user['id']
            session['username'] = user['username']
            flash('Login successful!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid credentials!', 'error')
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully!', 'success')
    return redirect(url_for('home'))

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    db = get_db()
    user = db.execute('SELECT * FROM users WHERE id = ?', (session['user_id'],)).fetchone()
    
    # Get recent activities
    activities = db.execute('''SELECT * FROM proofs 
                              WHERE user_id = ? 
                              ORDER BY created_at DESC 
                              LIMIT 5''', (session['user_id'],)).fetchall()
    db.close()
    
    tips = [
        "Try using public transport today! 🚌",
        "Plant a tree this weekend 🌳",
        "Bring your own bags when shopping 🛍️",
        "Start composting your food waste 🌱",
        "Switch to reusable water bottles 💧",
        "Reduce your meat consumption 🥗",
        "Turn off lights when leaving a room 💡",
        "Use cold water for laundry 🧺"
    ]
    
    return render_template('dashboard.html', user=user, activities=activities, tip=random.choice(tips))

@app.route('/upload_proof', methods=['GET', 'POST'])
def upload_proof():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        activity_type = request.form['activity_type']
        file = request.files['proof_image']
        
        if file and file.filename:
            filename = secure_filename(f"{session['user_id']}_{datetime.now().timestamp()}_{file.filename}")
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)
            
            db = get_db()
            db.execute('''INSERT INTO proofs (user_id, activity_type, image_path) 
                         VALUES (?, ?, ?)''', (session['user_id'], activity_type, filename))
            db.commit()
            db.close()
            
            flash('Proof uploaded! Waiting for admin verification.', 'success')
            return redirect(url_for('dashboard'))
    
    return render_template('upload_proof.html')

@app.route('/redeem', methods=['GET', 'POST'])
def redeem():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    db = get_db()
    user = db.execute('SELECT * FROM users WHERE id = ?', (session['user_id'],)).fetchone()
    rewards = db.execute('SELECT * FROM rewards ORDER BY cost').fetchall()
    
    if request.method == 'POST':
        reward_id = request.form['reward_id']
        reward = db.execute('SELECT * FROM rewards WHERE id = ?', (reward_id,)).fetchone()
        
        if user['coins'] >= reward['cost']:
            new_balance = user['coins'] - reward['cost']
            db.execute('UPDATE users SET coins = ? WHERE id = ?', (new_balance, session['user_id']))
            db.commit()
            flash(f'Successfully redeemed: {reward["name"]}! 🎉', 'success')
        else:
            flash('Not enough EcoCoins!', 'error')
        
        db.close()
        return redirect(url_for('redeem'))
    
    db.close()
    return render_template('redeem.html', user=user, rewards=rewards)

@app.route('/impact')
def impact():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    db = get_db()
    user = db.execute('SELECT * FROM users WHERE id = ?', (session['user_id'],)).fetchone()
    
    # Get activity data for charts
    activities_raw = db.execute('''SELECT activity_type, COUNT(*) as count, SUM(coins_earned) as coins
                              FROM proofs 
                              WHERE user_id = ? AND status = 'approved'
                              GROUP BY activity_type''', (session['user_id'],)).fetchall()
    
    # Convert to list of dicts for JSON
    activities = []
    for activity in activities_raw:
        activities.append({
            'activity_type': activity['activity_type'],
            'count': activity['count'],
            'coins': activity['coins'] or 0
        })
    
    db.close()
    return render_template('impact.html', user=user, activities=activities)

@app.route('/team')
def team():
    db = get_db()
    leaderboard = db.execute('''SELECT username, coins, activities, co2_saved 
                               FROM users 
                               ORDER BY coins DESC 
                               LIMIT 10''').fetchall()
    db.close()
    return render_template('team.html', leaderboard=leaderboard)

@app.route('/admin')
def admin():
    if 'user_id' not in session or session.get('username') != 'admin':
        flash('Admin access only!', 'error')
        return redirect(url_for('home'))
    
    db = get_db()
    proofs = db.execute('''SELECT p.*, u.username 
                          FROM proofs p 
                          JOIN users u ON p.user_id = u.id 
                          ORDER BY p.created_at DESC''').fetchall()
    
    stats = db.execute('''SELECT 
                         COUNT(*) as total,
                         SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
                         SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved
                         FROM proofs''').fetchone()
    db.close()
    
    return render_template('admin.html', proofs=proofs, stats=stats)

@app.route('/approve/<int:proof_id>')
def approve(proof_id):
    if 'user_id' not in session or session.get('username') != 'admin':
        return redirect(url_for('home'))
    
    db = get_db()
    proof = db.execute('SELECT * FROM proofs WHERE id = ?', (proof_id,)).fetchone()
    
    if proof:
        impact = calculate_impact(proof['activity_type'])
        
        db.execute('UPDATE proofs SET status = ?, coins_earned = ? WHERE id = ?',
                  ('approved', impact['coins'], proof_id))
        
        db.execute('''UPDATE users 
                     SET coins = coins + ?, 
                         activities = activities + 1,
                         co2_saved = co2_saved + ?
                     WHERE id = ?''', (impact['coins'], impact['co2'], proof['user_id']))
        db.commit()
        flash('Proof approved and coins awarded!', 'success')
    
    db.close()
    return redirect(url_for('admin'))

@app.route('/reject/<int:proof_id>')
def reject(proof_id):
    if 'user_id' not in session or session.get('username') != 'admin':
        return redirect(url_for('home'))
    
    db = get_db()
    db.execute('UPDATE proofs SET status = ? WHERE id = ?', ('rejected', proof_id))
    db.commit()
    db.close()
    
    flash('Proof rejected.', 'info')
    return redirect(url_for('admin'))

if __name__ == '__main__':
    app.run(debug=True)